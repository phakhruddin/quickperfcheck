#!/bin/bash
[ -d /root/PERF/ ] || mkdir /root/PERF/
echo "/root/PERF/checkiostat.spike.sh &
/root/PERF/checkneterror.spike.sh &
/root/PERF/checknetstatanp.spike.sh &
/root/PERF/checknetstat-s.spike.sh &
/root/PERF/checknstat.spike.sh &
/root/PERF/topstat.spike.sh &
/root/PERF/vmstat-stat.spike.sh &
/root/PERF/checksar.spike.sh &"
