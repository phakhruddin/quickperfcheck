#!/bin/bash
[ -d /root/PERF ] || mkdir /root/PERF
Date="`date +%Y%m%d`";date >> /root/PERF/sar-A.out.$Date;sar -A 1 3600 >> /root/PERF/sar-A.out.$Date
