#!/bin/bash
[ -d /root/PERF ] || mkdir /root/PERF
Date="`date +%Y%m%d`";while sleep 1;do date >> /root/PERF/vmstat-stat.out.$Date;vmstat 1 3600 >> /root/PERF/vmstat-stat.out.$Date;done
