#!/bin/bash
[ -d /root/PERF ] || mkdir /root/PERF
Date="`date +%Y%m%d`"; date >> /root/PERF/iostat-xn.out.$Date;iostat -xn 1 3600 >> /root/PERF/iostat-xn.out.$Date
