#!/bin/bash
[ -d /root/PERF ] || mkdir /root/PERF
Date="`date +%Y%m%d`";while sleep 1;do date >> /root/PERF/netstat-anp.out.$Date;netstat -anp >> /root/PERF/netstat-anp.out.$Date;NewDate="`date +%Y%m%d`";[ $NewDate -eq $Date ] || { exit 1; };done
