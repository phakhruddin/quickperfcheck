#!/bin/bash
[ -d /root/PERF ] || mkdir /root/PERF
Int="`netstat -r | grep default | awk '{print $NF}'`"
Date="`date +%Y%m%d`";while sleep 1;do date >> /root/PERF/neterror.out.${Int}.$Date;ip -s -s link ls $Int >> /root/PERF/neterror.out.${Int} ;done
